/*
Author : Allah Wasaya
Company : AQL Tech Solutions
1. In this program, It take name and age as input from the user.
2. The a pointer to character array is initialized having size of age.
3. age times names are stored in that array and then displayed. 
*/
/////////////////////////////// START ///////////////////////////////////////
#include <stdio.h>
int main()
{
    char name[20];
    int age;
    printf("Enter your name: ");
    scanf("%s",name);
    printf("Enter your age :");
    scanf("%d",&age);
    printf("My name is %s and my age is %d",name,age);
    char *arr[age];
    //printf("%p\n",arr);
    for (int i = 0; i < age; i++)
    {
        *(arr+i)=name;
    }
    printf("\n");
     for (int i = 0; i < age; i++)
    {
        printf("%s",*(arr+i));
    }
printf("\n");
}
/////////////////////////////  END ///////////////////////////////////////
